# 01. London

## Tasks
* Create a Web page **(HTML5 + CSS3)** that looks and behaves like the provided screenshots
* You have been given all of the **required resources**

## Constraints
* Use the Google font - [**"Montserrat"**](https://fonts.googleapis.com/css?family=Montserrat)
* Use **Font Awesome** for icons
* The web page should open correctly in the latest version of Chrome
* Pixel-perfect implementation is **NOT** required
